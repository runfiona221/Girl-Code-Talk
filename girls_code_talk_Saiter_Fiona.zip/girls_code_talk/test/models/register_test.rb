require 'test_helper'

class RegisterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
