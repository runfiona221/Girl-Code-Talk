require "application_system_test_case"

class RegistersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit registers_url
  #
  #   assert_selector "h1", text: "Register"
  # end
end
