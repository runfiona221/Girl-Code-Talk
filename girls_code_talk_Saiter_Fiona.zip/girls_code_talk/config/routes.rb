Rails.application.routes.draw do
  get '/' => 'users#login'
  post '/login' => 'users#doLogin'
  get '/home' => 'users#home'
  get '/forgotPassword' => 'users#forgotpassword'
  #get '/signup' => 'users#signup'

  # trying to set up a route between sing up here on the login page that goes to the registration page. didn't work. below.
  #"{post}" '/ users' => ' users#create'
  resources :users
  # root to: "users#index"
end
